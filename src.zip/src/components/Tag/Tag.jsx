import './Tag.css';

export default function Tag({name}){

    return <span className="tag">{name}</span>;
}